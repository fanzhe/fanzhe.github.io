#include <iostream>
#include <vector>
#include <set>
#include <string>
#include <string.h>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <list>
#include <time.h>
#include <map>
#include <queue>
#include <algorithm>

#include "gmp.h"
#include <stdio.h>
#include <assert.h>
#include <gmpxx.h>


//#define FHE_MODULE
//#define shortest_mod
#define EARLYSTOP
//#define MIDEBUG
//#define PRINTORNOT
// #define DISK
#define FILTER
// #define ORIGINAL
#define SPREFINEMENT
#define SPENUMERATION

#ifdef FHE_MODULE
extern "C"{
#include "fh/integer-fhe.h"
}
#endif

using namespace std;

class graph_t {
public:
    char type;
    int gid;
    int cnt_n, cnt_e;
    vector< set<int> > nodelabel;  // 1 ~ n
    vector< int > nodedegree; // 1 ~ n
    vector< vector <int> > node; // 1 ~ n

    // for traverse
    vector< set <int> > node_hops; // 1 ~ n
    vector< map <int, int> > node_hops_label_cnt; // 1 ~ n
    vector< map <int, int> > node_hops_path_label_sup; // 1 ~ n
    vector< map <int, int> > node_hops_fanout_cnt; // 1 ~ n
    vector< map <int, set<int> > > node_hops_label_cnt_pre; // 1 ~ n
    // vector< vector< map <int, set<int> > > > node_hops_label_cnt_post; // 1 ~ n
    // vector< vector< map <int, set<int> > > > node_hops_distinct_label; // 1 ~ n
    // vector< vector< map <int, set<int> > > > node_hops_two_later; // 1 ~ n

    int** M;
    mpz_t** B; // adjacent matrix of g, cnt_n * cnt_n
    // mpz_t** node_adj_l;
    mpz_t** elaborated_node_adj_l;
    mpz_t* disk_elaborated_node_adj_l;
    mpz_t* node_sum;

    int si_size;
};

class Result_t {
public:
    double query_time;
    double cnt_rounding;
    double msg_size;
    double decryption_time;
    double refine_rate;
    double refine_time;
    double answer;
    double matching_time;
    double non_answer;

    Result_t () {
        query_time = 0;
        cnt_rounding = 0;
        msg_size = 0;
        decryption_time = 0;
        refine_rate = 0;
        answer = 0;
        non_answer = 0;
        refine_time = 0;
        matching_time = 0;
    }
};

Result_t non_prune_result, prune_result; 

// version
int version;
int theta;
mpz_t* inner_result;
vector< vector<int> > inner_sep_result;
vector< vector<int> > inner_sep_indx;

// global label
int global_label = 0;
int global_label_part = 0;
int hops; // 0 ~ hops-1
int inner_hops;
int fanout_cnt;
int shortest_label;
int path_label_sup;
int elaborated_global_label = 0;
int elaborated_global_label_part = 0;
int label_cnt = 0;
int is_prelabel;

#ifdef FHE_MODULE
// used for fh subiso
mpz_t c0, c1;
fhe_pk_t pk;
fhe_sk_t sk;
#endif

// used for shortest distance
#define MAXSP 100000
#define DEFALTARRSIZE 1000
#define DEFALTALLPOSSIBLESMALLNUM 50

// used for enhanced subiso
#define DEFALTRAN 32 //128
mpz_t p, n, group, x, gx, gx_1, rand_num;
gmp_randstate_t r_state;

// enhaned ullman result
#define DEFALTSIZE 10000000
#define DEFALTMSGSIZE 2048
#define DEFALTHOPS 20
#define partition 16// 6
#define DEFALTMI 500000

mpz_t en_result;

// ullman result
mpz_t ull_result;

// used for all subiso
mpz_t** C, **C_tmp, **mi_tran, **MC, **mi;

// time
double decryption_time;
double en_query_time_no, en_query_time_yes;
double encrypt_q_only, encrypt_g_only;
double encrypt_q_si, encrypt_g_si;
double generate_q_si, generate_g_si;
double connected_prune_out, raw_prune_out, non_prune_out;
double avg_si_size;

double cnt_mi, cnt_rounding;
vector<int> cnt_ones_of_row;
vector<int> sorted_row;
int** row_col_next_one;

ofstream outsifile;


// function declarantion 
void disk_set_elaborated_extend_hops_node_adj_l (graph_t& g, int node_id, char worr);
void extend_hops_node_DFS (graph_t& g, int node_id);
void disk_clear_static_index_inner (graph_t& g);

bool my_sort_row_comp (int i, int j) {
    return (cnt_ones_of_row[i] < cnt_ones_of_row[j]);
}

double gettime (clock_t s, clock_t e) {
	return ((double)(e - s)) / CLOCKS_PER_SEC;
}

// a * b
// c : a_r * b_c
void matrix_mul (mpz_t **a, int a_r, int a_c, mpz_t **b, int b_r, int b_c, mpz_t** c) {
	mpz_t tmp;
	mpz_init(tmp);

	if (a_c != b_r) {
		cout << "matrix mul error" << endl;
		exit(0);
	}

	for (int i = 0; i < a_r; i++) {
		for (int j = 0; j < b_c; j++) {
			mpz_set_d(c[i][j], 0);
			for (int k = 0; k < a_c; k++) {
				//c[i][j] += a[i][k] * b[k][j];
				mpz_mul(tmp, a[i][k], b[k][j]);
				mpz_add(c[i][j], c[i][j], tmp);
			}
		}
	}

    mpz_clear(tmp);
}

// a transpose
void matrix_trans (mpz_t **a, int a_r, int a_c, mpz_t** _a) {
	for (int i = 0; i < a_r; i++) {
		for (int j = 0; j < a_c; j++) {
			mpz_set(_a[j][i], a[i][j]);
		}
	}
}

void matrix_init (int **&a, int a_r, int a_c) {
	a = (int**)malloc(a_r * sizeof(int *));
	for (int i = 0; i < a_r; i++) {
		*(a + i) = (int *) malloc(a_c * sizeof(int));
	}

	// init
	for (int i = 0; i < a_r; i++) {
		for (int j = 0; j < a_c; j++) {
			a[i][j] = 0;
			//gmp_printf("%Zd ", a[i][j]);
		}
	}
}

void vector_set (mpz_t*& a, int _size, int _value = 0) {
    for (int i = 0; i < _size; i ++) {
        mpz_set_d(a[i], _value);
    }
}

void vector_init (mpz_t*& a, int _size, int _value = 0) {
    a = (mpz_t*) malloc (_size * sizeof(mpz_t));
    for (int i = 0; i < _size; i++) {
        mpz_init(a[i]);
        mpz_set_d(a[i], _value);
    }
}

void vector_free (mpz_t*& a, int _size, int _value = 0) {
    for (int i = 0; i < _size; i++) {
        mpz_clear(a[i]);
	}

	free(a);
}

void matrix_init (mpz_t **&a, int a_r, int a_c) {

	// create
	//cout << "test matrix_init" << endl;

	a = (mpz_t**)malloc(a_r * sizeof(mpz_t*));
	for (int i = 0; i < a_r; i++) {
		*(a + i) = (mpz_t*) malloc(a_c * sizeof(mpz_t));
	}

	// init
	for (int i = 0; i < a_r; i++) {
		for (int j = 0; j < a_c; j++) {
			mpz_init(a[i][j]);
            mpz_set_d(a[i][j], 0);
			//gmp_printf("%Zd ", a[i][j]);
		}
	}

	//cout << "end test matrix_init" << endl;
}

void matrix_free (mpz_t **&a, int a_r, int a_c) {
	// init
	for (int i = 0; i < a_r; i++) {
		for (int j = 0; j < a_c; j++)
			mpz_clear(a[i][j]);
	}


	for (int i = 0; i < a_r; i++) {
		free(a[i]);
	}
	free(a);
}

void vector_print (mpz_t*& a, int _size) {
    cout << "vector_print " << endl;
    for (int i = 0; i < _size; i++) {
        gmp_printf("%Zd ", a[i]);
    }
    cout << endl;
}

void matrix_print (mpz_t** a, int a_r, int a_c) {
	for (int i = 0; i < a_r; i++) {
		for (int j = 0; j < a_c; j++)
			gmp_printf("%Zd ", a[i][j]);
		cout << endl;
	}
}

// a = b
void matrix_cpy (mpz_t** a, mpz_t** b, int a_r, int a_c) {
	for (int i = 0; i < a_r; i++) {
		for (int j = 0; j < a_c; j++) {
            mpz_set(a[i][j], b[i][j]);
        }
	}
}

void _mulmod (mpz_t& res, mpz_t& a, mpz_t& b, mpz_t& mod) {
    mpz_mul(res, a, b);
    mpz_mod(res, res, mod);
}

void _addmod (mpz_t& res, mpz_t& a, mpz_t& b, mpz_t& mod) {
    mpz_add(res, a, b);
    mpz_mod(res, res, mod);
}


void printGraph (graph_t &g) {

	cout << "node label: " << endl;
	for (int i = 1; i <= g.cnt_n; i++) {
        cout << i << " - ";
        for (set<int>::iterator it = g.nodelabel[i].begin(); it != g.nodelabel[i].end(); it++) {
	       cout << *it << " ";
        }
	}
	cout << endl;
	cout << "adjacent matrix: " << endl;

	matrix_print(g.B, g.cnt_n, g.cnt_n);
}

// simple inner product
bool inner_product(mpz_t*& v1, mpz_t*& v2, mpz_t& _sum) {
    mpz_t tmp, res;
    mpz_init(tmp);
    mpz_init(res);

    // attention
    for (int i = 0; i < elaborated_global_label; i++) {
        mpz_mul(tmp, v1[i], v2[i]);
        mpz_add(res, tmp, res);
    }

    // >= if we use degree info instead of the shortest distance info
    if (mpz_cmp(res, _sum) >= 0) {
        mpz_clear(tmp);
        mpz_clear(res);
        return true;
    } else {
        mpz_clear(tmp);
        mpz_clear(res);
        return false;
    }


}

// original Ullman inner
void _subiso_inner (graph_t& q, graph_t& g, mpz_t** mi, int _row, mpz_t& result) {

	// C = mi *  g.B * mi.transpose()
    // where mi only contains _row rows
	matrix_mul(mi, _row, g.cnt_n, g.B, g.cnt_n, g.cnt_n, C_tmp);
	matrix_trans(mi, _row, g.cnt_n, mi_tran);
	matrix_mul(C_tmp, _row, g.cnt_n, mi_tran, g.cnt_n, _row, C);

	for (int i = 0; i < _row; i++) {
		for (int j = 0; j < _row; j++) {
			if (mpz_cmp_d(q.B[i][j], 1) == 0) {
				if (mpz_cmp_d(C[i][j], 0)  == 0) {
					mpz_mul_ui(result, result, 1);
					return;
				}
			}
			if (mpz_cmp_d(q.B[i][j], 0) == 0) {
				continue;
			}
		}
	}
	mpz_mul_ui(result, result, 0);
}


bool inner_collect_result (int i_indx, int _size) {
    bool flag;
    mpz_t _tmp;
    mpz_init(_tmp);
    mpz_set_d(_tmp, 1);

    for (int i = 0; i < _size; i++) {
        mpz_mul(_tmp, _tmp, inner_result[i]);
    }

    if (mpz_cmp_d(_tmp, 0) == 0) {
        flag = true;
    } else {
        flag = false;
    }

    if (flag) {
        for (int i = 0; i < _size; i++) {
            if (mpz_cmp_d(inner_result[i], 0) == 0) {
                inner_sep_result[i_indx][i] = 0;
            } else {
                inner_sep_result[i_indx][i] = 1;
            }
        }
    }

    mpz_clear(_tmp);
    return flag;
}

void _inner_decrypt (mpz_t& _tmp, int _size) {

    mpz_t gx_m, cnt;
    mpz_init(gx_m);
    mpz_init(cnt);

    mpz_set_d(cnt, 2 * _size);
    mpz_powm(gx_m, gx_1, cnt, n);

    _mulmod(_tmp, _tmp, gx_m, n);
    
    mpz_mod(_tmp, _tmp, p);

    mpz_clear(cnt);
    mpz_clear(gx_m);
}


void _enhanced_subiso_inner (graph_t& q, graph_t& g, mpz_t** mi, int _row, mpz_t& result) {
    clock_t _s_time = clock();
    matrix_mul(mi, _row, g.cnt_n, g.B, g.cnt_n, g.cnt_n, C_tmp);
    matrix_trans(mi, _row, g.cnt_n, mi_tran);
    matrix_mul(C_tmp, _row, g.cnt_n, mi_tran, g.cnt_n, _row, C);

    // MC'
    for (int i = 0; i < _row; i++) {
        for (int j = 0; j < _row; j++) {
            _mulmod(MC[i][j], q.B[i][j], C[i][j], n);
        }
    }

    // record result
    mpz_set_d(result, 0);
    for (int i = 0; i < _row; i++) {
        for (int j = 0; j < _row; j++) {
            _addmod (result, result, MC[i][j], n);
        }
    }
    clock_t _e_time = clock();
    non_prune_result.matching_time += gettime(_s_time, _e_time);
}

bool _enhanced_inner_collect_result (int i_indx, int _size) {

    bool flag;
    mpz_t _tmp;
    mpz_init(_tmp);
    mpz_set_d(_tmp, 1);

    clock_t _s_time = clock();
    for (int i = 0; i < _size; i++) {
        _mulmod(_tmp, _tmp, inner_result[i], n);
    }
    clock_t _e_time = clock();
    non_prune_result.matching_time += gettime(_s_time, _e_time);

    // inner decryption once
    _s_time = clock();
    _inner_decrypt (_tmp, _size);
    _e_time = clock();
    decryption_time += gettime(_s_time, _e_time);

    if (mpz_cmp_d(_tmp, 0) == 0) {
        flag = true;
    } else {
        flag = false;
    }

    if (flag) {

        // inner decryption _size
        for (int i = 0; i < _size; i++) {
            // inner decryption
            _s_time = clock();
            _inner_decrypt(inner_result[i], 1);
            _e_time = clock();
            decryption_time += gettime(_s_time, _e_time);            
            
            if (mpz_cmp_d(inner_result[i], 0) == 0) {
                inner_sep_result[i_indx][i] = 0;
            } else {
                inner_sep_result[i_indx][i] = 1;
            }
        }
    }

    mpz_clear(_tmp);
    return flag;
}


#ifdef FHE_MODULE
void _OR (mpz_t& ac, mpz_t& tmp) {
	fhe_mul(tmp, tmp, tmp, pk);
	fhe_add(tmp, tmp, c1, pk);

	fhe_mul(ac, ac, ac, pk);
	fhe_add(ac, ac, c1, pk);

	fhe_mul(tmp, tmp, ac, pk);
	fhe_add(tmp, tmp, c1, pk);
}

// fully homomorphic based Ullman
void _fhsubiso (graph_t& q, graph_t& g, mpz_t** mi, mpz_t& result) {

	//C = mi *  g.B * mi.transpose()
	matrix_mul(mi, q.cnt_n, g.cnt_n, g.B, g.cnt_n, g.cnt_n, C_tmp);
	matrix_trans(mi, q.cnt_n, g.cnt_n, mi_tran);
	matrix_mul(C_tmp, q.cnt_n, g.cnt_n, mi_tran, g.cnt_n, q.cnt_n, C);

	// MC = q.B * C
	for (int i = 0; i < q.cnt_n; i++) {
		for (int j = 0; j < q.cnt_n; j++)
			fhe_mul(MC[i][j], q.B[i][j], C[i][j], pk);
	}

	// MC = MC + q.B
	for (int i = 0; i < q.cnt_n; i++) {
		for (int j = 0; j < q.cnt_n; j++)
			fhe_add(MC[i][j], MC[i][j], q.B[i][j], pk);
	}

	mpz_t tmp;
	mpz_init(tmp);

	// OR AC
	for (int i = 0; i < q.cnt_n; i++) {
		for (int j = 0; j < q.cnt_n; j++)
			_OR(MC[i][j], tmp);
	}
	//cout << "___1: " << fhe_decrypt(tmp, sk) << endl;
	// update result
	fhe_mul(result, result, tmp, pk);

	mpz_clear(tmp);
}
#endif


int enumM(mpz_t** m, int i_indx, int* col, int* row, graph_t& q, graph_t& g, mpz_t& result) {

	int row_size = q.cnt_n;
	int col_size = g.cnt_n;

#ifdef MIDEBUG
    if (cnt_mi > DEFALTMI)
        return 3;
#endif

#ifdef EARLYSTOP
    if (mpz_cmp_d(result, 0) == 0) {
        return 2;
    }
#endif

	if (i_indx == row_size) {
		return 1;
	}

	int inner_cnt = 0;

    // enumeration
    for (int _j = 0; _j < cnt_ones_of_row[i_indx]; _j++) {
        int j = row_col_next_one[i_indx][_j];
		// if (row[j] == 0 && mpz_cmp_d(mi[i_indx][j], 1) == 0) {
		if (row[j] == 0) {

			row[j] = 1;
			//col[i_indx] = j;
            inner_sep_indx[i_indx][inner_cnt] = j;
			for (int _j1 = 0; _j1 < cnt_ones_of_row[i_indx]; _j1++) {
                int j1 = row_col_next_one[i_indx][_j1];
				if (j1 == j)    mpz_set_d(mi[i_indx][j1], 1);
				else    mpz_set_d(mi[i_indx][j1], 0);
			}

            // ***************************************
            // theta test start
            // theta means the start depth of the search tree
            // ***************************************
#ifdef SPENUMERATION
            if (i_indx >= theta) 
#endif

#ifndef SPENUMERATION
            if (i_indx == row_size - 1)
#endif
            {
                row[j] = 0;
                
                if (version == 1)
                    _subiso_inner(q, g, mi, i_indx + 1, inner_result[inner_cnt ++]);
                if (version == 2) 
                    _enhanced_subiso_inner(q, g, mi, i_indx + 1, inner_result[inner_cnt ++]);

                if (i_indx == row_size - 1) {
                    cnt_mi ++;
                }

                // be careful of the constraints
                if (inner_cnt == partition || _j == (cnt_ones_of_row[i_indx] - 1) || (row[row_col_next_one[i_indx][(_j + 1)]] == 1 && _j == (cnt_ones_of_row[i_indx] -2))) {
                    // return to client
                    bool _flag;
                    if (version == 1)
                        _flag = inner_collect_result(i_indx, inner_cnt);
                    if (version == 2)
                        _flag = _enhanced_inner_collect_result(i_indx, inner_cnt);
                    
                    cnt_rounding ++;

                    // re-set value in inner_result as 1
                    vector_set(inner_result, partition, 1);

                    if (!_flag) {
                        // NO answer
                        inner_cnt = 0;
                        continue;
                    } else {
                        // YES answer
                        // for each correct cols

#ifdef EARLYSTOP
                        if (i_indx == row_size - 1) {
                            mpz_set_d(result, 0); 
                            return 1;
                        }
#endif

                        cnt_rounding += inner_cnt;

                        for (int k = 0; k < inner_cnt; k++) {
                            if (inner_sep_result[i_indx][k] == 0) {
                                int j2 = inner_sep_indx[i_indx][k];

                                row[j2] = 1;
                                for (int _j1 = 0; _j1 < cnt_ones_of_row[i_indx]; _j1++) {
                                    int j1 = row_col_next_one[i_indx][_j1];
                                    if (j1 == j2)   mpz_set_d(mi[i_indx][j1], 1);
                                    else    mpz_set_d(mi[i_indx][j1], 0);
                                }

#ifdef PRINTORNOT
                                cout << "TTT" << endl;
                                matrix_print(mi, i_indx + 1, col_size);
                                cout << "RRR" << endl;
#endif

                                enumM(m, i_indx + 1, col, row, q, g, result);

#ifdef MIDEBUG
                                if (cnt_mi > DEFALTMI)
                                    return 3;
#endif

#ifdef EARLYSTOP
                                if (mpz_cmp_d(result, 0) == 0) {
                                    return 2;
                                }
#endif

                                row[j2] = 0;
                                for (int _j1 = 0; _j1 < cnt_ones_of_row[i_indx]; _j1++) {
                                    int j1 = row_col_next_one[i_indx][_j1];
                                    mpz_set(mi[i_indx][j1], m[i_indx][j1]);
                                }
                            }
                        }
                        inner_cnt = 0;
                        continue;
                    }
                }
            } 
            // ***************************************
            // theta test end
            // ***************************************
            else  {
                // continue to recurse
                enumM(m, i_indx + 1, col, row, q, g, result);

#ifdef MIDEBUG
                if (cnt_mi > DEFALTMI)
                    return 3;
#endif

#ifdef EARLYSTOP
                if (mpz_cmp_d(result, 0) == 0) {
                    return 2;
                }
#endif

                row[j] = 0;
                for (int _j1 = 0; _j1 < cnt_ones_of_row[i_indx]; _j1++) {
                    int j1 = row_col_next_one[i_indx][_j1];
                    mpz_set(mi[i_indx][j1], m[i_indx][j1]);
                }
            }
		}
	}
	return 0;
}

void Ullman (mpz_t** m, graph_t& q, graph_t& g) {

	int* col = new int [q.cnt_n];

	//cout << "test0 " << endl;
	int * row = new int[g.cnt_n];
	for (int i = 0; i < g.cnt_n; i++) {
		row[i] = 0;
	}
    

	enumM(m, 0, col, row, q, g, ull_result);

	//enumM(m, 0, col, q, g, ull_result);
	//gmp_printf("result: %Zd\n", result);

	delete[] col;
    delete[] row;
}

void en_initKey () {
	// random and prime number init
	mpz_init(rand_num);
	mpz_init(p);
	mpz_init(n);
    mpz_init(group);
    mpz_init(x);
    mpz_init(gx);
    mpz_init(gx_1);

    // generate prime number p
    mpz_set_d(p, 2147483647);

    // g^x % n
	gmp_randinit_default(r_state);
	gmp_randinit_mt(r_state);
    // mpz_urandomb(n, r_state, DEFALTMSGSIZE);
    mpz_set_str(n, "16594900510468848618779859529048970562434151887982758146333908610126995606875959583150754096904939163058088732836622155984787148951754484085080055100022863834734805390568247562546896289033380553816126638204887528488669669650795595078243509793710242842807549471564349489475385605450605971121686746302940877979192119330073120037897310684720105742251875954769621467756551735273135476454843803189963924528556657594267637567873522001475725298702714900996470201476441839588209221083986823968709674978326806081379946096271872621299301620422089624262355737113475982440526827509351111547011077378815198009079208558801443913617", 10);
    mpz_urandomb(x, r_state, DEFALTMSGSIZE);

    mpz_set_d(group, 3);
    mpz_powm(gx, group, x, n);
    mpz_invert(gx_1, gx, n);

    //gmp_printf("n: %Zd \n", n);
    //gmp_printf("x: %Zd \n", x);
    //gmp_printf("g^x: %Zd \n", gx);
    //gmp_printf("g^x_1: %Zd \n", gx_1);

    /* test encyrpt, subiso, decryt
    mpz_t a, b, c;
    mpz_init(a);
    mpz_init(b);
    mpz_init(c);
    mpz_urandomb(rand_num, r_state, 128);
    mpz_set(a, rand_num);
    gmp_printf("rand_num %Zd \n", rand_num);
    mpz_mul(a, a, rand_num);
    _mulmod(a, a, gx, n);

    mpz_urandomb(rand_num, r_state, 128);
    gmp_printf("rand_num %Zd \n", rand_num);
    mpz_set(b, rand_num);
    _mulmod(b, b, gx, n);

    _mulmod(c, a, b, n);

    _mulmod(c, c, gx_1, n);
    _mulmod(c, c, gx_1, n);
    mpz_mod(c, c, p);
    gmp_printf("test result: %Zd \n", c);
    */
}

// double enhanced_msg_size() {
//     count MB
//     double size = (en_result_arr_size * DEFALTMSGSIZE) / (8 * 1024 * 1024);
//     return size;
// }


double simulate_encryption_si (graph_t& g) {
    mpz_t _tmp;
    mpz_init(_tmp);
    clock_t _s_time = clock();
    for (int k = 0; k < g.cnt_n; k++) {
        for (int i = 0; i < 2 * avg_si_size; i++) {
            for (int j = 0; j < avg_si_size; j++) {
                mpz_mul(_tmp, g.elaborated_node_adj_l[1][0], g.elaborated_node_adj_l[1][0]);
                mpz_add(_tmp, _tmp, _tmp);
            }
        }
    }
    clock_t _e_time = clock();
    mpz_clear(_tmp);
    return gettime(_s_time, _e_time);
}


void en_encryptQuery (graph_t& q) {
	// encrypt q.B
	for (int i = 0; i < q.cnt_n; i++) {
		for (int j = 0; j < q.cnt_n; j++) {
			mpz_urandomb(rand_num, r_state, DEFALTRAN);
            // gmp_printf("random: %Zd \n", rand_num);
			// gmp_printf("%Zd \n", rand_num);
			if ( mpz_cmp_d(q.B[i][j], 0) == 0 ) {
				mpz_mul(q.B[i][j], p, rand_num);
				_mulmod(q.B[i][j], q.B[i][j], gx, n);
			}
			else if ( mpz_cmp_d(q.B[i][j], 1) == 0 ) {
				mpz_set(q.B[i][j], rand_num);
				_mulmod(q.B[i][j], q.B[i][j], gx, n);
			}
			else {
				cout << "error q.B entry" << endl;
				cout << "q.cnt_n" << q.cnt_n << endl;
				matrix_print(q.B, q.cnt_n, q.cnt_n);
				printGraph(q);
				exit(0);
			}
		}
	}
}

void en_encryptGraph (graph_t& g) {
	// encrypt g.B
	for (int i = 0; i < g.cnt_n; i++) {
		for (int j = 0; j < g.cnt_n; j++) {
			mpz_urandomb(rand_num, r_state, DEFALTRAN);
			if (mpz_cmp_d(g.B[i][j], 0) == 0) {
				mpz_set(g.B[i][j], rand_num);
				_mulmod(g.B[i][j], g.B[i][j], gx, n);
			}
			else if (mpz_cmp_d(g.B[i][j], 1) == 0) {
				mpz_mul(g.B[i][j], p, rand_num);
				_mulmod(g.B[i][j], g.B[i][j], gx, n);
			}
			else {
				cout << "error g.B entry" << endl;
				exit(0);
			}
		}
	}
}


void enhancedUllman (mpz_t** m, graph_t& q, graph_t& g) {
    

	int* col = new int[q.cnt_n];
	int * row = new int[g.cnt_n];
	for (int i = 0; i < g.cnt_n; i++) {
		row[i] = 0;
	}

	enumM(m, 0, col, row, q, g, en_result);

	delete[] col;
	delete[] row;
}


#ifdef FHE_MODULE
// fully homomorphic based Ullman portal
void fhUllman (mpz_t** m, graph_t& q, graph_t& g) {

	int* col = new int[q.cnt_n];
	int* row = new int[g.cnt_n];
	for (int i = 0; i < g.cnt_n; i++) {
		row[i] = 0;
	}

	//fully homomorphic init
	mpz_init(c0);
	mpz_init(c1);

	fhe_pk_init(pk);
	fhe_sk_init(sk);

	cout << "generating keys." << endl;
	fhe_keygen(pk, sk);
	cout << "keys generate finished." << endl;

	cout << "encryption." << endl;
	fhe_encrypt(c0, pk, 0);
	fhe_encrypt(c1, pk, 1);
	cout << "encryption finished." << endl;

	// encryt q.B
	for (int i = 0; i < q.cnt_n; i++) {
		for (int j = 0; j < q.cnt_n; j++) {
			if ( mpz_cmp_d(q.B[i][j], 0) == 0 ) {
				mpz_set(q.B[i][j], c0);
			}
			else if ( mpz_cmp_d(q.B[i][j], 1) == 0 ) {
				mpz_set(q.B[i][j], c1);
			}
			else {
				cout << "fh q.B error" << endl;
			}
		}
	}

	// encryt q.B
	for (int i = 0; i < g.cnt_n; i++) {
		for (int j = 0; j < g.cnt_n; j++) {
			if ( mpz_cmp_d(g.B[i][j], 0) == 0 ) {
				mpz_set(g.B[i][j], c0);
			}
			else if ( mpz_cmp_d(g.B[i][j], 1) == 0 ) {
				mpz_set(g.B[i][j], c1);
			}
			else {
				cout << "fh g.B error" << endl;
			}
		}
	}

	// init result
	mpz_t result;
	mpz_init(result);
	mpz_set_d(result, 1);

	enumM(m, 0, col, row, q, g, result);

	int r_m = fhe_decrypt(result, sk);

	cout << "result: " << r_m << endl;

	// clear all
	delete[] col;
    delete[] row;

	mpz_clear(result);
	mpz_clear(c0);
	mpz_clear(c1);

	fhe_pk_clear(pk);
    fhe_sk_clear(sk);
}
#endif

bool zero_row_prune (mpz_t** m, graph_t& q, graph_t& g) {
    int row_size = q.cnt_n;
    int col_size = g.cnt_n;

    for (int i = 0; i < row_size; i++) {
        for (int j = 0; j < col_size; j++) {
            if (mpz_cmp_d(m[i][j], 1) == 0)
                break;
            if (j == col_size - 1)
                return false;
        }
    }
    return true;
}

void connect_prune (mpz_t** m, graph_t& q, graph_t& g) {
	int row_size = q.cnt_n;
    int col_size = g.cnt_n;
    bool _flag;
    int max = 1000;

#ifdef DISK
    for (int j = 0; j < col_size; j++) {
        _flag = false;
        for (int i = 0; i < row_size; i++) {
            if (mpz_cmp_d(m[i][j], 1) == 0) {
                _flag = true;
                break;
            }
        }

        if (_flag) {
            // read SI for j of G
            // TGDO
            
            // prune
            for (int i = 0; i < row_size; i++) {
                // if (!inner_product(q.elaborated_node_adj_l[i], g.elaborated_node_adj_l[j], q.node_sum[i])) {
                if (!inner_product(q.elaborated_node_adj_l[i], g.disk_elaborated_node_adj_l, q.node_sum[i])) {
                    mpz_set_d(m[i][j], 0);
                }
            }

            // clear read SI
            // TODO
            
        }
    }
#endif 

#ifndef DISK
    // *************************************
    // original prune
    // *************************************
	for (int i = 0; i < row_size; i++) {
		for (int j = 0; j < col_size; j++) {
			if (mpz_cmp_d(m[i][j], 1) == 0) {

                if (!inner_product(q.elaborated_node_adj_l[i], g.elaborated_node_adj_l[j], q.node_sum[i])) {
                    mpz_set_d(m[i][j], 0);
                }

			}
		}
    }
    // *************************************
    // original prune
    // *************************************
#endif 
}

void cnt_all_possible_number (mpz_t** m, graph_t& q, graph_t& g, double* _vec) {
    for (int i = 0; i < q.cnt_n; i++) {
        int _cnt = 0;
        for (int j = 0; j < g.cnt_n; j++) {
            if (mpz_cmp_d(m[i][j], 1) == 0) {
                _cnt ++;
            }
        }
        _vec[i] = _cnt;
    }
}


void cnt_ones_of_row_function(graph_t& q, graph_t& g) {
    for (int i = 0; i < q.cnt_n; i++) {
        int _cnt = 0;
        for (int j = 0; j < g.cnt_n; j++) {
            if (mpz_cmp_d(mi[i][j], 1) == 0) {
                row_col_next_one[i][_cnt] = j;
                _cnt ++;
            }
        }
        cnt_ones_of_row[i] = _cnt;
        sorted_row[i] = i;
    }
}

void sort_row_function(graph_t& q) {
    sort(sorted_row.begin(), sorted_row.begin() + q.cnt_n, my_sort_row_comp);

#ifdef PRINTORNOT
    cout <<  "\nsorted_row: ";
    for (int i = 0; i < q.cnt_n; i++) {
        cout << sorted_row[i] << "-" << cnt_ones_of_row[sorted_row[i]] << " ";
    }
    cout << endl;
#endif

}

void undo_sort_query_vertex(graph_t&q, graph_t& g, mpz_t**& m) {
    // sort row_col_next_one
    int** mii = (int**) malloc(q.cnt_n * sizeof(int*));
    for(int i = 0; i < q.cnt_n; i++) {
        int s_r = sorted_row[i];
        mii[s_r] = row_col_next_one[i];
    }
    for(int i = 0; i < q.cnt_n; i++)  row_col_next_one[i] = mii[i];
    free(mii);

    // sort mi
    mpz_t** mii_prime = (mpz_t**)malloc(q.cnt_n * sizeof(mpz_t*));
    for(int i = 0; i < q.cnt_n; i++) {
        int s_r = sorted_row[i];
        mii_prime[s_r] = mi[i];
    }
    for(int i = 0; i < q.cnt_n; i++)  mi[i] = mii_prime[i];

    // sort m
    for(int i = 0; i < q.cnt_n; i++) {
        int s_r = sorted_row[i];
        mii_prime[s_r] = m[i];
    }
    for(int i = 0; i < q.cnt_n; i++)  m[i] = mii_prime[i];

    // sort q.B
    // sort row
    for(int i = 0; i < q.cnt_n; i++) {
        int s_r = sorted_row[i];
        mii_prime[s_r] = q.B[i];
    }
    for(int i = 0; i < q.cnt_n; i++)  q.B[i] = mii_prime[i];
    free(mii_prime);

    // sort col
    matrix_init(mii_prime, q.cnt_n, q.cnt_n);
    for (int i = 0; i < q.cnt_n; i++) {
        int s_r = sorted_row[i];
        for (int j = 0; j < q.cnt_n; j++) {
            mpz_set(mii_prime[j][s_r], q.B[j][i]);
        }
    }
    for (int i = 0; i < q.cnt_n; i++) {
        for (int j = 0; j < q.cnt_n; j++) {
            mpz_set(q.B[i][j], mii_prime[i][j]);
        }
    }
    matrix_free(mii_prime, q.cnt_n, q.cnt_n);

    // sort cnt_ones_of_row
    int* tmp_int_arr = new int[q.cnt_n];
    for (int i = 0; i < q.cnt_n; i++) {
        int s_r = sorted_row[i];
        for (int j = 0; j < q.cnt_n; j++) {
            tmp_int_arr[s_r] = cnt_ones_of_row[i];
        }
    }
    for (int i = 0; i < q.cnt_n; i++) cnt_ones_of_row[i] = tmp_int_arr[i];
    delete[] tmp_int_arr;

#ifdef PRINTORNOT
    cout <<  "\n after undo sorted_row \n";
    for (int i = 0; i < q.cnt_n; i++) {
        cout << i << "-" << cnt_ones_of_row[i] << " ";
    }
    cout << endl;

    cout <<  "\n after undo row_col_next_one \n";
    for (int i = 0; i < q.cnt_n; i++) {
        cout << "r: " << i << " - ";
        for (int j = 0; j < cnt_ones_of_row[i]; j++) {
            cout << row_col_next_one[i][j] << " ";
        }
        cout << endl;
    }
#endif

}

void sort_query_vertex(graph_t& q, graph_t& g, mpz_t**& m) {
    // sort row_col_next_one
    int** mii = (int**) malloc(q.cnt_n * sizeof(int*));
    for(int i = 0; i < q.cnt_n; i++) {
        int s_r = sorted_row[i];
        mii[i] = row_col_next_one[s_r];
    }
    for(int i = 0; i < q.cnt_n; i++)  row_col_next_one[i] = mii[i];
    free(mii);

    // sort mi
    mpz_t** mii_prime = (mpz_t**)malloc(q.cnt_n * sizeof(mpz_t*));
    for(int i = 0; i < q.cnt_n; i++) {
        int s_r = sorted_row[i];
        mii_prime[i] = mi[s_r];
    }
    for(int i = 0; i < q.cnt_n; i++)  mi[i] = mii_prime[i];

    // sort m
    for(int i = 0; i < q.cnt_n; i++) {
        int s_r = sorted_row[i];
        mii_prime[i] = m[s_r];
    }
    for(int i = 0; i < q.cnt_n; i++)  m[i] = mii_prime[i];

    // sort q.B
    // sort row
    for(int i = 0; i < q.cnt_n; i++) {
        int s_r = sorted_row[i];
        mii_prime[i] = q.B[s_r];
    }
    for(int i = 0; i < q.cnt_n; i++)  q.B[i] = mii_prime[i];
    free(mii_prime);

    // sort col
    matrix_init(mii_prime, q.cnt_n, q.cnt_n);
    for (int i = 0; i < q.cnt_n; i++) {
        int s_r = sorted_row[i];
        for (int j = 0; j < q.cnt_n; j++) {
            mpz_set(mii_prime[j][i], q.B[j][s_r]);
        }
    }
    for (int i = 0; i < q.cnt_n; i++) {
        for (int j = 0; j < q.cnt_n; j++) {
            mpz_set(q.B[i][j], mii_prime[i][j]);
        }
    }
    matrix_free(mii_prime, q.cnt_n, q.cnt_n);

    // sort cnt_ones_of_row
    int* tmp_int_arr = new int[q.cnt_n];
    for (int i = 0; i < q.cnt_n; i++) {
        int s_r = sorted_row[i];
        for (int j = 0; j < q.cnt_n; j++) {
            tmp_int_arr[i] = cnt_ones_of_row[s_r];
        }
    }
    for (int i = 0; i < q.cnt_n; i++) cnt_ones_of_row[i] = tmp_int_arr[i];
    delete[] tmp_int_arr;

#ifdef PRINTORNOT
    cout <<  "\n after sorted_row \n";
    for (int i = 0; i < q.cnt_n; i++) {
        cout << i << "-" << cnt_ones_of_row[i] << " ";
    }
    cout << endl;

    cout <<  "\n after row_col_next_one \n";
    for (int i = 0; i < q.cnt_n; i++) {
        cout << "r: " << i << " - ";
        for (int j = 0; j < cnt_ones_of_row[i]; j++) {
            cout << row_col_next_one[i][j] << " ";
        }
        cout << endl;
    }
#endif
}


// Ullman portal
int ullman_main_portal (graph_t& q, graph_t& g) {
	// create M
	mpz_t** m;

	matrix_init(m, q.cnt_n, g.cnt_n);
	matrix_init(C, q.cnt_n, q.cnt_n);
	matrix_init(C_tmp, q.cnt_n, g.cnt_n);
	matrix_init(mi_tran, g.cnt_n, q.cnt_n);
	matrix_init(MC, q.cnt_n, q.cnt_n);
	matrix_init(mi, q.cnt_n, g.cnt_n);

    // assign value in m
	for (int i = 0; i < q.cnt_n; i++) {
		for (int j = 0; j < g.cnt_n; j++) {

            if (g.nodelabel[j+1].find( *(q.nodelabel[i+1].begin()) ) != g.nodelabel[j+1].end()) {
				mpz_set_d(m[i][j], 1);
			}
            else {
                mpz_set_d(m[i][j], 0);
            }
        }
    }

    // zero row pruning
    if (!zero_row_prune(m, q, g)) {
        cout << "zero_row_prune success" << endl;
        return 1;
    }

#ifdef PRINTORNOT
    // neighbor-basd pruning
    ///*
    cout << "before prune M: " << endl;
    matrix_print(m, q.cnt_n, g.cnt_n);
#endif

    // count all possible 
    double _before_all[DEFALTALLPOSSIBLESMALLNUM];
    cnt_all_possible_number(m, q, g, _before_all);

    clock_t _s_time = clock();
#ifdef SPREFINEMENT
    connect_prune(m, q, g);
#endif
    clock_t _e_time = clock();

#ifdef PRINTORNOT
    cout << "after prune M: " << endl;
    matrix_print(m, q.cnt_n, g.cnt_n);
    //*/
#endif

    // zero row pruning again
    if (!zero_row_prune(m, q, g)) {
        cout << "connect_prune success" << endl;
        return 2;
    }

    double _after_all[DEFALTALLPOSSIBLESMALLNUM];
    cnt_all_possible_number(m, q, g, _after_all);

    // **************
    double _rate = 1;
    for(int i = 0 ; i < q.cnt_n; i++) {
        _rate *= _after_all[i] / _before_all[i];
    }
    non_prune_result.refine_rate += 1 - _rate;

    non_prune_result.refine_time += gettime(_s_time, _e_time);
    // **************


    // mi = m
    matrix_cpy(mi, m, q.cnt_n, g.cnt_n);

#ifdef PRINTORNOT
    cout << "after prune Mi: " << endl;
    matrix_print(mi, q.cnt_n, g.cnt_n);
    cout << "original Q: " << endl;
    matrix_print(q.B, q.cnt_n, q.cnt_n);
#endif

    // cnt ones in each row
    cnt_ones_of_row_function(q, g);
    // sort
    sort_row_function(q);
    sort_query_vertex(q, g, m);

#ifdef PRINTORNOT
    cout << "after sort m" << endl;
    matrix_print(m, q.cnt_n, g.cnt_n);
    cout << "after sort mi" << endl;
    matrix_print(mi, q.cnt_n, g.cnt_n);
    cout << "after sort Q" << endl;
    matrix_print(q.B, q.cnt_n, q.cnt_n);
#endif

    // so far
	if (version == 1) {
		Ullman(m, q, g);
	} else if (version == 2) {
		enhancedUllman(m, q, g);
	} else {
#ifdef FHE_MODULE
		fhUllman(m, q, g);
#endif
	}

    undo_sort_query_vertex(q, g, m);

	matrix_free(C, q.cnt_n, q.cnt_n);
	matrix_free(C_tmp, q.cnt_n, g.cnt_n);
	matrix_free(mi_tran, g.cnt_n, q.cnt_n);
	matrix_free(MC, q.cnt_n, q.cnt_n);
	matrix_free(m, q.cnt_n, g.cnt_n);
	matrix_free(mi, q.cnt_n, g.cnt_n);

    return 3;
}


void init_matrix_for_ullman (graph_t& g) {

    matrix_init(g.B, g.cnt_n, g.cnt_n);

    for (int i = 0; i < g.cnt_n; i++) {
        for (int j = 0; j < g.cnt_n; j++) {
            if (g.M[i][j]  == 1) {
                mpz_set_d(g.B[i][j], 1);
            }
            else if (g.M[i][j] == 0) {
                mpz_set_d(g.B[i][j], 0);
            }
            else {
                cout << "error init_matrix_for_ullman \n";
            }
        }
    }
}

void init_static_index (graph_t& g, char GorQ) {
    int v_cnt = g.cnt_n;

    g.node_hops.resize(hops);
    g.node_hops_label_cnt.resize(hops);
    g.node_hops_path_label_sup.resize(hops);
    g.node_hops_fanout_cnt.resize(hops);
    g.node_hops_label_cnt_pre.resize(hops);
    // g.node_hops_label_cnt_post.resize(hops);
    // g.node_hops_distinct_label.resize(hops);
    // g.node_hops_two_later.resize(hops);

    vector_init(g.node_sum, v_cnt);

    vector_init(g.disk_elaborated_node_adj_l, elaborated_global_label);

    if (GorQ == 'q')
        matrix_init(g.elaborated_node_adj_l, g.cnt_n, elaborated_global_label);

    if (GorQ == 'g') {
#ifndef DISK
        matrix_init(g.elaborated_node_adj_l, g.cnt_n, elaborated_global_label);     
#endif        
    }
}

void clear_static_index_inner (graph_t& g) {
    for (int i = 0; i < hops; i++) {
        g.node_hops[i].clear();
        g.node_hops_label_cnt[i].clear();
        g.node_hops_path_label_sup[i].clear();
        g.node_hops_fanout_cnt[i].clear();
        g.node_hops_label_cnt_pre[i].clear();
        // g.node_hops_label_cnt_post[i].clear();
        // g.node_hops_distinct_label[i].clear();
        // g.node_hops_two_later[i].clear();
    }
}

void disk_clear_static_index_inner (graph_t& g) {
    for (int i = 0; i < hops; i++) {
        g.node_hops[i].clear();
        g.node_hops_label_cnt[i].clear();
        g.node_hops_path_label_sup[i].clear();
        g.node_hops_fanout_cnt[i].clear();
        g.node_hops_label_cnt_pre[i].clear();
        // g.node_hops_label_cnt_post[i].clear();
        // g.node_hops_distinct_label[i].clear();
        // g.node_hops_two_later[i].clear();
    }

    // only difference with the above function
    vector_set(g.disk_elaborated_node_adj_l, elaborated_global_label);
}

void clear_static_index (graph_t& g, char GorQ) {
    for (int i = 0; i < hops; i++) {
        g.node_hops[i].clear();
        g.node_hops_label_cnt[i].clear();
        g.node_hops_path_label_sup[i].clear();
        g.node_hops_fanout_cnt[i].clear();
        g.node_hops_label_cnt_pre[i].clear();
        // g.node_hops_label_cnt_post[i].clear();
        // g.node_hops_distinct_label[i].clear();
        // g.node_hops_two_later[i].clear();
    }

    g.node_hops.clear();
    g.node_hops_label_cnt.clear();
    g.node_hops_path_label_sup.clear();
    g.node_hops_fanout_cnt.clear();
    g.node_hops_label_cnt_pre.clear();
    // g.node_hops_label_cnt_post.clear();
    // g.node_hops_distinct_label.clear();
    // g.node_hops_two_later.clear();

    vector_set(g.node_sum, g.cnt_n);

    if (GorQ == 'q')
        matrix_free(g.elaborated_node_adj_l, g.cnt_n, elaborated_global_label);

    if (GorQ == 'g') {
#ifndef DISK
        matrix_free(g.elaborated_node_adj_l, g.cnt_n, elaborated_global_label);        
#endif
    }

    vector_free(g.disk_elaborated_node_adj_l, elaborated_global_label);
}

void clear_matrix_for_ullman (graph_t& g) {
    matrix_free(g.B, g.cnt_n, g.cnt_n);
}


// true is in, false otherwise
bool is_in_path(vector<int>& path, int dep, int v) {
    // check if v is in path already
    bool isFind = false;
    for (int j = 0; j < dep; j++) {
        if (path[j] == v) {
            isFind = true;
            break;
        }
    }
    return isFind;
}

// void collect_later(vector<int>& path, graph_t& g, int node_id, int dep, int v) {
//     int v_l = g.nodelabel[v];
//     for (int i = 0; i < g.nodedegree[v]; i++) {
//         int next_v = g.node[v][i];
//         if (!is_in_path(path, dep, v) && next_v != node_id) {
//             // not in
//             for (int j = 0; j < g.nodedegree[next_v]; j++) {
//                 int next_next_v = g.node[next_v][j];
//                 if (!is_in_path(path, dep, v) != next_next_v != node_id) {
//                     // not in
//                     int next_next_v_l = g.nodelabel[next_next_v];
//                     g.node_hops_two_later[node_id][dep - 1][v_l].insert(next_next_v_l);
//                 }
//             }
//         }
//     }
// }

void collect_inner(vector<int>& path, graph_t& g, int node_id, int dep, int v) {
    // v and v_l are the (dep-1)th hop node and label
    g.node_hops[dep - 1].insert(v);
    
    for (set<int>::iterator it1 = g.nodelabel[v].begin(); it1 != g.nodelabel[v].end(); it1 ++) {
        int v_l = *it1;
        
        if (g.node_hops_fanout_cnt[dep - 1][v_l] < g.nodedegree[v]) {
            g.node_hops_fanout_cnt[dep - 1][v_l] = g.nodedegree[v];
        }

        g.node_hops_path_label_sup[dep - 1][v_l] ++;

        int pre_v = path[dep - 1];
        for (set<int>::iterator it2 = g.nodelabel[pre_v].begin(); it2 != g.nodelabel[pre_v].end(); it2++) {
            int pre_v_l = *it2;
            g.node_hops_label_cnt_pre[dep - 1][v_l].insert(pre_v_l);
        }


        // all the labels in path are the same
        // if (dep >= 2) {
        //     int _flag = 1;

        //     for (set<int>::iterator it1 = g.nodelabel[path[1]].begin(); it1 != g.nodelabel[path[1]].end(); it1++) {
        //         int _tmp_l = *it1;
        //         for (int i = 2; i < dep - 1; i++) {
        //             if (g.nodelabel[path[i]].find(_tmp_l) == g.nodelabel[path[i]].end()) {
        //                 _flag = 0;
        //                 break;
        //             }
        //         }
        //         if (_flag == 0) 
        //             break;
        //     }

        //     if (_flag == 1) {
        //         for (set<int>::iterator it1 = g.nodelabel[path[1]].begin(); it1 != g.nodelabel[path[1]].end(); it1++) {
        //             int _tmp_l = *it1;
        //             g.node_hops_distinct_label[node_id][dep - 1][v_l].insert(_tmp_l);
        //         }
        //     }
        // }
    }

    /*
    if (dep >= 2) {
        int _pre_two_hop_v = path[dep - 2];
        if (g.nodedegree[_pre_two_hop_v] > 2) {
            int _pre_two_hop_v_l = g.nodelabel[_pre_two_hop_v];
            g.node_hops_two_later[node_id][dep - 3][_pre_two_hop_v_l].insert(v_l);
        }
    }
    */

    // if (dep >= 1 && g.nodedegree[v] > 2) {
    //     collect_later(path, g, node_id, dep, v);
    // }
}

void collect (graph_t& g, int node_id, vector<int>& path) {
    // for each hop i
    for (int i = 0; i < hops; i++) {
        // for each node u in hop i
        for (set<int>::iterator it = g.node_hops[i].begin(); it != g.node_hops[i].end(); it++) {
            int u = *it;
            
            for (set<int>::iterator it = g.nodelabel[u].begin(); it != g.nodelabel[u].end(); it++) {
                int u_l = *it;
                // count label
                g.node_hops_label_cnt[i][u_l] ++;
            }
        }
    }

}

// DFS inner
void extend_hops_node_DFS_inner (graph_t& g, int cur_node_id, int dep, vector<int>& path, int node_id) {

    if (dep > hops) {
        return;
    }

    // for each neighbor node v of cur_node_id
    for (int i = 0; i < g.nodedegree[cur_node_id]; i++) {
        int v = g.node[cur_node_id][i];

        // check if v is in path already
        bool isFind = is_in_path(path, dep, v);

        if (isFind) {
            //cout << "found id " << v << endl;
            continue;
        }

        // put v in path
        path[dep] = v;
        collect_inner(path, g, node_id, dep, v);
        extend_hops_node_DFS_inner (g, v, dep + 1, path, node_id);
        path[dep] = -1;
    }

}

// DFS similar extend
void extend_hops_node_DFS (graph_t& g, int node_id) {

    vector<int> path;
    path.resize(hops + 1);
    for (int i = 0; i < hops + 1; i++) {
        path[i] = -1;
    }
    //put node_id in path first
    path[0] = node_id;

    extend_hops_node_DFS_inner (g, node_id, 1, path, node_id);

    collect(g, node_id, path);

    // if (g.type == 'g' && g.gid == 126 && node_id == 15) {
    //     int i = 0;
    //     cout << "label_cnt\n";
    //     set<int> tmp;
    //     for (map<int, int>::iterator it = g.node_hops_label_cnt[node_id][i].begin(); it != g.node_hops_label_cnt[node_id][i].end(); it++) {
    //         //cout << "gid: " << g.gid << " nid: " << node_id << " hop: " << i << " label: " << it->first << " cnt: " << it->second << endl;
    //         cout << "label: " << it->first << " cnt: " << it->second << endl;
    //         for (set<int>::iterator it1 = g.node_hops_label_cnt_pre[node_id][i][it->first].begin(); it1 != g.node_hops_label_cnt_pre[node_id][i][it->first].end(); it1++) {
    //             cout << " label: " << it->first << " pre_label: " << *it1 << endl;
    //         }
    //         for (set<int>::iterator it1 = g.node_hops_distinct_label[node_id][i][it->first].begin(); it1 != g.node_hops_distinct_label[node_id][i][it->first].end(); it1++) {
    //             cout << " label: " << it->first << " distinct label: " << *it1 << endl;
    //         }
    //         for (set<int>::iterator it1 = g.node_hops_two_later[node_id][i][it->first].begin(); it1 != g.node_hops_two_later[node_id][i][it->first].end(); it1++) {
    //             cout << " label: " << it->first << " two later label: " << *it1 << endl;
    //         }
    //     }

    //     cout << "\nfanout_cnt\n";
    //     for (map<int, int>::iterator it = g.node_hops_fanout_cnt[node_id][i].begin(); it != g.node_hops_fanout_cnt[node_id][i].end(); it++) {
    //         cout << "label: " << it->first << " cnt: " << it->second << endl;
    //     }
    // }
}


void set_elaborated_extend_hops_node_adj_l (graph_t& g, int node_id) {
    // for each hops
    for (int i = 0; i < hops; i++) {
        //if (g.gid == 3)
        //    cout << "node_id " << node_id << " & hop " << i << endl;
        // for each node label in current hop
        for (map<int, int>::iterator it = g.node_hops_label_cnt[i].begin(); it != g.node_hops_label_cnt[i].end(); it++) {
            int adj_l = it->first;
            int adj_l_cnt = it->second;

            /*
               if (g.type == 'q' && g.gid == 1 && i == 5 && node_id == 9) {
               cout << adj_l << " " << adj_l_cnt << " " << g.node_hops_fanout_cnt[node_id][i][adj_l] << endl;
               for (set<int>::iterator it1 = g.node_hops_label_cnt_pre[node_id][i][adj_l].begin(); it1 != g.node_hops_label_cnt_pre[node_id][i][adj_l].end(); it1++) {
               cout << *it1 << " ";
               }
               cout << endl;
               }

               if (g.type == 'g' && g.gid == 27 && i == 5 && node_id == 12) {
               cout << endl;
               cout << adj_l << " " << adj_l_cnt << " " << g.node_hops_fanout_cnt[node_id][i][adj_l] << endl;
               for (set<int>::iterator it1 = g.node_hops_label_cnt_pre[node_id][i][adj_l].begin(); it1 != g.node_hops_label_cnt_pre[node_id][i][adj_l].end(); it1++) {
               cout << *it1 << " ";
               }
               cout << endl;
               }
               */


            int indx = (inner_hops + label_cnt * is_prelabel + fanout_cnt + path_label_sup); //+ label_cnt + label_cnt);
            // current hop label cnt
            for (int j = 0; j < adj_l_cnt && j < inner_hops; j++) {
                int ind = 1 + ( indx * adj_l) + j + (i * elaborated_global_label_part);
                //cout << "ind " << ind << " " << elaborated_global_label << endl;
                mpz_set_d(g.elaborated_node_adj_l[node_id - 1][ind], 100);
            }

            // pre hop label
            if (is_prelabel == 1) {
                for (set<int>::iterator it1 = g.node_hops_label_cnt_pre[i][adj_l].begin(); it1 != g.node_hops_label_cnt_pre[i][adj_l].end(); it1++) {
                    int ind = 1 + ( indx  * adj_l) + (inner_hops + *it1) + (i * elaborated_global_label_part);
                    mpz_set_d(g.elaborated_node_adj_l[node_id - 1][ind], 100);
                }
            }

            // current hop label fanout cnt
            int fo = g.node_hops_fanout_cnt[i][adj_l];
            for (int j = 0; j < fo && j < fanout_cnt; j++) {
                int ind = 1 + ( indx  * adj_l) + (inner_hops + label_cnt * is_prelabel + j) + (i * elaborated_global_label_part);
                mpz_set_d(g.elaborated_node_adj_l[node_id - 1][ind], 100);
            }

            // current hop path label sup
            int pls = g.node_hops_path_label_sup[i][adj_l];
            for (int j = 0; j < pls && j < path_label_sup; j++) {
                int ind = 1 + ( indx * adj_l) + (inner_hops + label_cnt * is_prelabel + fanout_cnt + j) + (i * elaborated_global_label_part);
                mpz_set_d(g.elaborated_node_adj_l[node_id - 1][ind], 100);
            }


            // current hop distinct label cnt
            // for (set<int>::iterator it1 = g.node_hops_distinct_label[node_id][i][adj_l].begin(); it1 != g.node_hops_distinct_label[node_id][i][adj_l].end(); it1++) {
            //     int ind = 1 + ( indx * adj_l) + (inner_hops + label_cnt + fanout_cnt + path_label_sup + *it1) + (i * elaborated_global_label_part);
            //     mpz_set_d(g.elaborated_node_adj_l[node_id - 1][ind], 100);
            // }

            // two hop later label
            // for (set<int>::iterator it1 = g.node_hops_two_later[node_id][i][adj_l].begin(); it1 != g.node_hops_two_later[node_id][i][adj_l].end(); it1++) {
            //     int ind = 1 + ( indx * adj_l) + (inner_hops + label_cnt + fanout_cnt + path_label_sup + label_cnt + *it1) + (i * elaborated_global_label_part);
            //     mpz_set_d(g.elaborated_node_adj_l[node_id - 1][ind], 100);
            // }
        }

        // set adj_id label degree
        if (i + 1 == hops)
            continue;
        //mpz_set_d(g.elaborated_node_adj_l[node_id - 1][(i + 1) * elaborated_global_label_part], 0); // max_degree);
    }

    // set node_id label degree
    mpz_set_d(g.elaborated_node_adj_l[node_id - 1][0], g.nodedegree[node_id]);

    mpz_t tmp;
    mpz_init(tmp);
    for (int i = 0; i < elaborated_global_label; i++) {
        mpz_mul(tmp, g.elaborated_node_adj_l[node_id - 1][i], g.elaborated_node_adj_l[node_id - 1][i]);
        mpz_add(g.node_sum[node_id - 1], g.node_sum[node_id - 1], tmp);
    }
    mpz_clear(tmp);
}


void set_elaborated_node_adj_l (graph_t& g, char GorQ) {
    // for each node
    for (int j = 0; j < g.cnt_n; j++) {
        int node_id = j + 1;

        // cout << node_id << endl;

        // DFS performs
        extend_hops_node_DFS(g, node_id);
        // extend_hops_node(g, node_id);
        // shortest_distance(g, node_id);

        set_elaborated_extend_hops_node_adj_l(g, node_id);
        clear_static_index_inner(g);
    }
}


void disk_set_elaborated_extend_hops_node_adj_l (graph_t& g, int node_id, char worr) {
    // for each hops
    for (int i = 0; i < hops; i++) {
        //if (g.gid == 3)
        //    cout << "node_id " << node_id << " & hop " << i << endl;
        // for each node label in current hop
        for (map<int, int>::iterator it = g.node_hops_label_cnt[i].begin(); it != g.node_hops_label_cnt[i].end(); it++) {
            int adj_l = it->first;
            int adj_l_cnt = it->second;

            int indx = (inner_hops + label_cnt * is_prelabel + fanout_cnt + path_label_sup); //+ label_cnt + label_cnt);
            // current hop label cnt
            for (int j = 0; j < adj_l_cnt && j < inner_hops; j++) {
                int ind = 1 + ( indx * adj_l) + j + (i * elaborated_global_label_part);
                //cout << "ind " << ind << " " << elaborated_global_label << endl;
                mpz_set_d(g.disk_elaborated_node_adj_l[ind], 100);
            }

            // pre hop label
            if (is_prelabel == 1) {
                for (set<int>::iterator it1 = g.node_hops_label_cnt_pre[i][adj_l].begin(); it1 != g.node_hops_label_cnt_pre[i][adj_l].end(); it1++) {
                    int ind = 1 + ( indx  * adj_l) + (inner_hops + *it1) + (i * elaborated_global_label_part);
                    mpz_set_d(g.disk_elaborated_node_adj_l[ind], 100);
                }
            }

            // current hop label fanout cnt
            int fo = g.node_hops_fanout_cnt[i][adj_l];
            for (int j = 0; j < fo && j < fanout_cnt; j++) {
                int ind = 1 + ( indx  * adj_l) + (inner_hops + label_cnt * is_prelabel + j) + (i * elaborated_global_label_part);
                mpz_set_d(g.disk_elaborated_node_adj_l[ind], 100);
            }

            // current hop path label sup
            int pls = g.node_hops_path_label_sup[i][adj_l];
            for (int j = 0; j < pls && j < path_label_sup; j++) {
                int ind = 1 + ( indx * adj_l) + (inner_hops + label_cnt * is_prelabel + fanout_cnt + j) + (i * elaborated_global_label_part);
                mpz_set_d(g.disk_elaborated_node_adj_l[ind], 100);
            }
        }
        if (i + 1 == hops)
            continue;
    }

    mpz_set_d(g.disk_elaborated_node_adj_l[0], g.nodedegree[node_id]);

    mpz_t tmp;
    mpz_init(tmp);
    for (int i = 0; i < elaborated_global_label; i++) {
        mpz_mul(tmp, g.disk_elaborated_node_adj_l[i], g.disk_elaborated_node_adj_l[i]);
        mpz_add(g.node_sum[node_id - 1], g.node_sum[node_id - 1], tmp);
    }

    // write to file 
    if (worr == 'w') {
        for (int i = 0; i < elaborated_global_label; i++) {
            mpz_class _tmp1(g.disk_elaborated_node_adj_l[i]);
            outsifile << _tmp1.get_str() << " ";
        }
        outsifile << endl;
    }

    mpz_clear(tmp);
}

void disk_set_elaborated_node_adj_l (graph_t& g, char GorQ) {

    g.elaborated_node_adj_l = NULL;

    for (int j = 0; j < g.cnt_n; j++) {
        int node_id = j + 1;

        cout << node_id << endl;
        
        extend_hops_node_DFS(g, node_id);

        disk_set_elaborated_extend_hops_node_adj_l(g, node_id, 'w');

        disk_clear_static_index_inner(g);
    }
}

void filter(graph_t*& query_set, int& no_query, set<int>& filter_out, set<int>& filter_out_g) {
    // for each query graph
    for (int i = 0; i < no_query; i++) {

        bool _flag = false;
        // for the label of the first vertex
        int v_l1 = *(query_set[i].nodelabel[1].begin());
        // for each following vertex
        for (int j = 2; j <= query_set[i].cnt_n; j++) {
            int v_l2 = *(query_set[i].nodelabel[j].begin());

            // exists differences
            if (v_l1 != v_l2) {
                _flag = true;
                break;
            }
        }

        // if all labels of the query graph are the same
        // if (_flag == false) {
        // if exists pair of labels that are different
        // if (_flag == true) {
            // record this query graph
            // filter_out.insert(i);
        // }
    }

    // for graph
    // filter_out_g.insert(976);
}


// read graph set
void readGraphSet (graph_t*& graph_set, char* filename, int _size, char type) {

    string line;
    ifstream infile (filename);

    if (!infile) {
        cout << "wrong filename " << filename << endl;
        return;
    }

    int flag = -1, id = 0;
    int v_cnt, e_cnt;


    while (id < _size) {
        getline(infile, line);
        istringstream i1 (line);

        i1 >> flag >> id;
        
        // cout << flag << " " << id << endl;
        
        graph_set[id].gid = id;
        graph_set[id].type = type;

        getline(infile, line);
        // cout << line << endl;
        istringstream i2 (line);

        i2 >> v_cnt >> e_cnt;

        // cout << v_cnt << " " << e_cnt << endl;

        graph_set[id].cnt_n = v_cnt;
        graph_set[id].cnt_e = e_cnt;

        graph_set[id].node.resize(v_cnt + 1);
        graph_set[id].nodelabel.resize(v_cnt + 1);
        graph_set[id].nodedegree.resize(v_cnt + 1);

        int t_v;
        int t_l;

        // cout << "test t" << endl;

        // set graph node label
        set<int> distinct_label;
        for (int i = 0; i < v_cnt; i++) {
            getline(infile, line);
            istringstream i3 (line);
            i3 >> t_v;
            // cout << t_v << " " << t_l << endl;
            while (i3 >> t_l) {
                graph_set[id].nodelabel[t_v].insert(t_l);
                distinct_label.insert(t_l);

                if (global_label < t_l)
                    global_label = t_l;

                if (elaborated_global_label < t_l)
                    elaborated_global_label = t_l;
            }
        }

        // create adjacent matrix
        matrix_init(graph_set[id].M, v_cnt, v_cnt);
        // cout << "test0" << endl;

        // init adjacent matrix
        for (int i = 0; i < v_cnt; i++) {
            for (int j = 0; j < v_cnt; j++) {
                if (i == j)
                    graph_set[id].M[i][j] = 1;
                else
                    graph_set[id].M[i][j] = 0;
            }
        }
        //cout << "test1" << endl;

        int v = 1;

        // set adjacency matrix
        for (int i = 0; i < v_cnt; i++) {
            getline(infile, line);
            istringstream i4 (line);
            int d_cnt = 0;
            while (i4 >> t_v) {
                // cout << t_v << " ";
                if (v == t_v) 
                    continue;
                d_cnt ++;
                graph_set[id].node[v].push_back(t_v);
                graph_set[id].M[v - 1][t_v - 1] = 1;
            }
            // cout << endl;
            graph_set[id].nodedegree[v] = d_cnt;
            v++;
        }

        // cout << endl; 

        // simulate si size       
        avg_si_size += distinct_label.size();

        id ++;
    }

    cout << "finish read " << id << " graph" << endl;
}

void print_result(ostream& out, double max_cnt_mi, double min_cnt_mi, double total_cnt_mi, double max_cnt_rounding, double min_cnt_rounding, double total_cnt_rounding, int no_query, int no_graph, int ullman_total_result, int en_total_result, int false_positive, double u_t_time, double e_t_time, double method2_encrypt_q_time, double method2_encrypt_g_time, double method2_decrypt_time, double e_msg_size, int** answer) {

    // global infor
    out << "global information: " << endl;
    out << "----query size: " << no_query << endl;
    out << "----graph size: " << no_graph << endl;

    double total_query_issued = no_query * no_graph;
    out << "----total_query_issued: " << total_query_issued << endl;

    double en_total_non_result = total_query_issued - en_total_result;
    out << "----en_total_result: " << en_total_result << endl;
    out << "----en_total_non_result: " << en_total_non_result << endl;

    out << "---- " << total_query_issued << " ?= " << raw_prune_out << " + " << connected_prune_out << " + " << non_prune_out
                    << " = "  << raw_prune_out + connected_prune_out + non_prune_out << endl;

    out << endl << endl;

    // SI size
    out << "----static index size: " << elaborated_global_label << endl;
    out << "----avg. si size: " << avg_si_size << endl; 

    // encryption time of query and graph
    out << "--g" << endl;
    out << "----total encryption g time (ms): " << (method2_encrypt_g_time / (no_query * no_graph) + encrypt_g_si) * 1000 << endl;
    out << "----generate SI g time (ms): " << (generate_g_si / (no_query * no_graph)) * 1000 << endl; 
    out << "----encrypt g only time (ms): " << (encrypt_g_only / (no_query * no_graph)) * 1000 << endl; 
    out << "----encrypt g si time (ms): " << encrypt_g_si * 1000 << endl; 
    out << "--q" << endl;
    out << "----total encryption q time (ms): " << (method2_encrypt_q_time / no_query + encrypt_q_si) * 1000 << endl;
    out << "----generate SI q time (ms): " << (generate_q_si / no_query) * 1000 << endl;
    out << "----encrypt q only time (ms): " << (encrypt_q_only / no_query) * 1000 << endl; 
    out << "----encrypt q si time (ms): " << encrypt_q_si * 1000 << endl; 

    out << endl << endl;

    // raw prune out
    {
        out << "raw prune out information: " << endl;
        out << "----raw prune out number: " << raw_prune_out << endl;
        out << "----raw prune ratio (%): " << (raw_prune_out / total_query_issued) * 100 << endl;
    }

    out << endl << endl;

    // prune out
    // non answer
    {
        out << "prune out information: " << endl;
        double _prune_out = connected_prune_out + non_prune_out;
        out << "----prune out number: " << connected_prune_out << endl;
        // query time
        out << "----query time (ms): " << (prune_result.query_time / connected_prune_out) * 1000 << endl;
        // no rounding
        // no messge size
        // no decryption time
        // refine ratio
        out << "----refine ratio (%): " << (connected_prune_out / _prune_out) * 100 << endl;
    }

    out << endl << endl;

    // non prune out
    {
        out << "non prune out information: " << endl;
        out << "----non prune out number: " << non_prune_out << endl;
        // answer number
        out << "----answer number: " << non_prune_result.answer << endl;
        out << "----non answer number: " << non_prune_result.non_answer << endl;
        out << "----answer ratio (%): " << (non_prune_result.answer / non_prune_out) * 100 << endl;
        out << "----non answer ratio (%): " << (non_prune_result.non_answer / non_prune_out) * 100 << endl;

        // query time
        out << "----query time (ms): " << (non_prune_result.query_time / non_prune_out) * 1000 << endl;
        out << "----sprefinement time (ms): " << (non_prune_result.refine_time / non_prune_out) * 1000 << endl;
        out << "----spmatching time (ms): " << (non_prune_result.matching_time / non_prune_out) * 1000 << endl;
        out << "----spenumeration time (ms): " << ((non_prune_result.query_time - non_prune_result.refine_time - non_prune_result.matching_time) / non_prune_out) * 1000 << endl;
        // rounding 
        double avg_cnt_rounding = total_cnt_rounding / non_prune_out;
        out << "----avg. total_cnt_rounding: " << avg_cnt_rounding << endl;

        // message size
        double msg_size = (avg_cnt_rounding * DEFALTMSGSIZE) / (1024 * 8);
        out << "----avg. message size (KB) " <<  msg_size << endl;

        // decrytpion time
        out << "----decryption time (ms): " << (decryption_time / non_prune_out) * 1000 << endl;

        // effectiveness of refine
        out << "----refine ratio (%): " << (non_prune_result.refine_rate / non_prune_out) * 100 << endl;
    }

    // out << "----min_cnt_rounding: " << min_cnt_rounding << endl;
    // out << "----max_cnt_rounding: " << max_cnt_rounding << endl;

    // out << "max_cnt_mi: " << max_cnt_mi << endl;
    // out << "min_cnt_mi: " << min_cnt_mi << endl;
    // double avg_cnt_mi = total_cnt_mi / (no_query * no_graph);
    // out << "avg. total_cnt_mi: " << avg_cnt_mi << endl;

    // out << "average ullman time " << u_t_time / (no_query * no_graph) << endl;
    // out << "average enhanced time " << e_t_time / (no_query * no_graph) << endl;

    // out << "Answer\n ";
    // for (int i = 0; i < no_query; i++) {
    //     out << "Query ID: " << i << " === ";
    //     for (int j = 0; j < no_graph; j++) {
    //         if (answer[i][j] == 0)
    //             out << j << " ";
    //     }
    //     out << endl;
    // }

    out << endl; 
}

void init_label () {
    // | degree + global_label_part | ^ hops
    // global_label += 2;
    // global_label_part = global_label;
    // global_label *= hops;

    // cout << "global_label " << global_label << endl;
    // cout << "global_label_part " << global_label_part << endl;

    elaborated_global_label += 1;
    label_cnt = elaborated_global_label;
    elaborated_global_label = inner_hops * label_cnt; // label cnt
    if (is_prelabel == 1)
        elaborated_global_label += label_cnt * label_cnt; // pre label
    elaborated_global_label += fanout_cnt * label_cnt; // max fanout
    elaborated_global_label += path_label_sup * label_cnt; // path sup
    // elaborated_global_label += label_cnt * label_cnt; // distinct label cnt
    // elaborated_global_label += label_cnt * label_cnt; // two hop later label
    elaborated_global_label_part = elaborated_global_label;
    elaborated_global_label *= hops;

    // for node_id degree
    elaborated_global_label += 1;

    // for shortest label, fails
    //elaborated_global_label += shortest_label * label_cnt;

    //set_node_adj_l(query_set, no_query);
    //set_node_adj_l(data_set, no_graph);

    cout << "elaborated_global_label " << elaborated_global_label << endl;
    cout << "elaborated_global_label_part " << elaborated_global_label_part << endl;
}

void init_early_stop () {
    vector_init(inner_result, partition, 1);
    inner_sep_result.resize(DEFALTARRSIZE);
    inner_sep_indx.resize(DEFALTARRSIZE);

    for (int i = 0; i < DEFALTARRSIZE; i++) {
        inner_sep_result[i].resize(DEFALTARRSIZE);
        inner_sep_indx[i].resize(DEFALTARRSIZE);
    }
}


int main(int argc, char* argv[]) {
    if (argc <= 1) {
        cout << "wrong input" << endl;
        return 0;
    }

    clock_t s_time, e_time;
    double u_t_time, e_t_time;
    double method2_encrypt_q_time = 0, method2_encrypt_g_time = 0,  method2_decrypt_time = 0;
    double e_msg_size = 0;
    int ullman_total_result = 0, en_total_result = 0;
    double max_cnt_mi = 0, min_cnt_mi = 10000000, total_cnt_mi = 0;
    double max_cnt_rounding = 0, min_cnt_rounding = 10000000, total_cnt_rounding = 0;

    int false_positive = 0;
    int midebug_cnt = 0;

    cnt_ones_of_row.resize(DEFALTARRSIZE);
    sorted_row.resize(DEFALTARRSIZE);
    matrix_init(row_col_next_one, DEFALTARRSIZE, DEFALTARRSIZE);

    // all grpah data
    graph_t* data_set;
    graph_t* query_set;
    int no_query = atoi(argv[2]);
    int no_graph = atoi(argv[4]);

    string out_file_name = string(argv[1]) + ".H" + string(argv[5]) + ".L" + string(argv[10]) + ".Occur" + string(argv[6]) 
                            + ".MaxDeg" + string(argv[7]) + ".Sup" + string(argv[8]) + ".Prelabel" + string(argv[9]) + ".result";
    cout << out_file_name << endl;

    ofstream out_file (out_file_name.c_str());

    if (!out_file) {
        cout << "wrong filename " << out_file_name << endl;
        return 1;
    }

    query_set = new graph_t[no_query];
    data_set = new graph_t[no_graph];

    hops = atoi(argv[5]);

    inner_hops = atoi(argv[6]);
    fanout_cnt = atoi(argv[7]);
    path_label_sup = atoi(argv[8]);
    //shortest_label = atoi(argv[9]);
    is_prelabel = atoi(argv[9]);
    theta = atoi(argv[10]);

    avg_si_size = 0;

    readGraphSet(query_set, argv[1], no_query, 'q');

    set<int> filter_out;
    set<int> filter_out_g;

#ifdef FILTER
    filter(query_set, no_query, filter_out, filter_out_g);
#endif

    readGraphSet(data_set, argv[3], no_graph, 'g');

    avg_si_size = avg_si_size / (no_query + no_graph);
    avg_si_size = (inner_hops + label_cnt * is_prelabel + fanout_cnt + path_label_sup) * avg_si_size * hops;
    
    // init label
    init_label();
    init_early_stop();

#ifdef DISK
    // *********************************************
    // Generate SI for graph
    // *********************************************
    outsifile.open("/home/zfan/yeast.si");
    for (int i = 0; i < no_graph; i++) {
        init_matrix_for_ullman(data_set[i]);
        init_static_index(data_set[i], 'g');
        cout << "SI for G start" << endl;
        disk_set_elaborated_node_adj_l(data_set[i], 'g');
        cout << "SI for G end" << endl;
        clear_static_index(data_set[i], 'g');
    }
    outsifile.close();
    return 0;
    // *********************************************
    // *********************************************
#endif


#ifdef ORIGINAL
    // *********************************************
    // Ullmann original method
    // *********************************************
    mpz_init(ull_result);

    int** _ullman = new int* [no_query];
    for (int i = 0; i < no_query; i++) {
        _ullman[i] = new int [no_graph];
    }

    u_t_time = 0;

    for (int i = 0; i < no_query; i++) {

#ifdef FILTER
        // find one
        if (filter_out.find(i) != filter_out.end()) {
            continue;
        }
#endif
        s_time = clock();
        // init matrix for ullman
        init_matrix_for_ullman(query_set[i]);
        // static index for query, at client side
        init_static_index(query_set[i], 'q');
        // cout << "SI for Q start" << endl;
        set_elaborated_node_adj_l(query_set[i], 'q');
        // cout << "SI for Q finish" << endl;
        e_time = clock();
        u_t_time += gettime(s_time, e_time);

        for (int j = 0; j < no_graph; j++) {

#ifdef FILTER
        // find one
        if (filter_out_g.find(j) != filter_out_g.end()) {
            continue;
        }
#endif
            cout << "Q - G: " << i << " - " << j << endl;

            // start
            
            // init matrix for ullman
            init_matrix_for_ullman(data_set[j]);
            // static index for graph
            init_static_index(data_set[j], 'g');
            // cout << "SI for G start" << endl;
#ifndef DISK
            set_elaborated_node_adj_l(data_set[j], 'g');
#endif
            // cout << "SI for G finish" << endl;
            mpz_set_d(ull_result, 1);
            version = 1;
            s_time = clock();
            ullman_main_portal(query_set[i], data_set[j]);
            e_time = clock();
            // end 
            u_t_time += gettime(s_time, e_time);

#ifdef MIDEBUG
            if (cnt_mi > DEFALTMI) {
                midebug_cnt ++;
            }
#endif

            // collect result
            if (mpz_cmp_d(ull_result, 0) == 0) {
                _ullman[i][j] = 0;
                ullman_total_result ++;
                // cout << 0 << endl;
            }
            else {
                _ullman[i][j] = 1;
                // cout << 1 << endl;
            }
            clear_matrix_for_ullman(data_set[j]);
            clear_static_index(data_set[j], 'g');
            //cout << "." << i << " " << j << endl;
        }

        clear_matrix_for_ullman(query_set[i]);
        clear_static_index(query_set[i], 'q');

    }
    cout << endl;
#endif 

#ifdef MIDEBUG
    cout << endl << "MIDEBUG: " << midebug_cnt << endl;
#endif

    // print_result(cout, max_cnt_mi, min_cnt_mi, total_cnt_mi, max_cnt_rounding, min_cnt_rounding, total_cnt_rounding, no_query, no_graph, ullman_total_result, en_total_result, false_positive, u_t_time, e_t_time, method2_encrypt_q_time,method2_encrypt_g_time,  method2_decrypt_time, e_msg_size, _ullman);

    // print_result(out_file, max_cnt_mi, min_cnt_mi, total_cnt_mi, max_cnt_rounding, min_cnt_rounding, total_cnt_rounding, no_query, no_graph, ullman_total_result, en_total_result, false_positive, u_t_time, e_t_time, method2_encrypt_q_time,method2_encrypt_g_time,  method2_decrypt_time, e_msg_size, _ullman);


    // *********************************************
    // CGB method
    // *********************************************
    
    mpz_init(en_result);
    
    int** _en = (int**) malloc (no_query * sizeof(int*));
    for (int i = 0; i < no_query; i++) {
        _en[i] = (int*) malloc (no_graph * sizeof(int));
    }

    en_initKey();

    e_t_time = 0;

    decryption_time = 0;
    en_query_time_yes = en_query_time_no = 0;
    raw_prune_out = connected_prune_out = non_prune_out = 0;
    encrypt_q_only = encrypt_g_only = 0;
    generate_q_si = generate_g_si = 0;
    clock_t _s_time, _e_time;

    for (int i = 0; i < no_query; i++) {

#ifdef FILTER
        // find one
        if (filter_out.find(i) != filter_out.end()) {
            continue;
        }
#endif
        // init matrix for en_ullman
        // cout << "SI for Q start" << endl;
        init_matrix_for_ullman(query_set[i]);
        // encrypt query 
        s_time = clock();
        // static index for query, at client side
        _s_time = clock();
#ifdef SPREFINEMENT        
        init_static_index(query_set[i], 'q');
        set_elaborated_node_adj_l(query_set[i], 'q');
#endif
        _e_time = clock();
        generate_q_si += gettime(_s_time, _e_time);
        // cout << "SI for Q finish" << endl;
        // encrypt query 
        _s_time = clock();
        en_encryptQuery(query_set[i]);
        _e_time = clock();
        encrypt_q_only += gettime(_s_time, _e_time);

        e_time = clock();
        method2_encrypt_q_time += gettime(s_time, e_time);

        e_t_time += gettime(s_time, e_time);

#ifdef SPREFINEMENT
        if(i == 0) {
            encrypt_q_si = simulate_encryption_si(query_set[0]);
        }
#endif

        for (int j = 0; j < no_graph; j++) {

#ifdef FILTER
            // find one
            if (filter_out_g.find(j) != filter_out_g.end()) {
                continue;
            }
#endif
            
            cout << "Q - G: " << i << " - " << j << endl;
            
            cnt_mi = cnt_rounding = 0;
            version = 2;
            
            // init matrix for ullman
            init_matrix_for_ullman(data_set[j]);
            // encrypt graph
            s_time = clock();
            // init SI for graph
            _s_time = clock();
#ifdef SPREFINEMENT            
            init_static_index(data_set[j], 'g');
            // generate SI 
            set_elaborated_node_adj_l(data_set[j], 'g');
            // cout << "SI for G finish" << endl;
#endif
            _e_time = clock();
            generate_g_si += gettime(_s_time, _e_time);
            // encrypt graph
            _s_time = clock();
            en_encryptGraph(data_set[j]);
            _e_time = clock();
            encrypt_g_only += gettime(_s_time, _e_time);
            
            e_time = clock();
            method2_encrypt_g_time += gettime(s_time, e_time);

#ifdef SPREFINEMENT
            if(j == 0) {
                encrypt_g_si = simulate_encryption_si(data_set[0]);
            }
#endif

            mpz_set_d(en_result, 1);

            // start
            s_time = clock();
            int ret_type = ullman_main_portal(query_set[i], data_set[j]);
            e_time = clock();
            e_t_time += gettime(s_time, e_time);
            // end

            // count Mi
            if (max_cnt_mi < cnt_mi) {
                max_cnt_mi = cnt_mi;
            }
            if (min_cnt_mi > cnt_mi) {
                min_cnt_mi = cnt_mi;
            }
            total_cnt_mi += cnt_mi;

            // count # of rounding
            if (max_cnt_rounding < cnt_rounding) {
                max_cnt_rounding = cnt_rounding;
            }
            if (min_cnt_rounding > cnt_rounding) {
                min_cnt_rounding = cnt_rounding;
            }
            total_cnt_rounding += cnt_rounding;

            // count return 
            if (ret_type == 1) {
                // raw prune out 
                raw_prune_out ++;
                //prune_result.query_time += gettime(s_time, e_time);
            } else if (ret_type == 2) {
                // connect prune out
                connected_prune_out ++;
                prune_result.query_time += gettime(s_time, e_time);
            } else {
                // non prune out
                non_prune_out ++;
                non_prune_result.query_time += gettime(s_time, e_time);
            }

            // count result
            if (mpz_cmp_d(en_result, 0) == 0) {
                _en[i][j] = 0;
                en_total_result ++;
                en_query_time_yes += gettime(s_time, e_time);

                non_prune_result.answer ++;
            }
            else {
                _en[i][j] = 1;
                en_query_time_no += gettime(s_time, e_time);
                
                if (ret_type == 3) {
                    non_prune_result.non_answer ++;
                }
            }

            clear_matrix_for_ullman(data_set[j]);
#ifdef SPREFINEMENT
            clear_static_index(data_set[j], 'g');
#endif
        }
        clear_matrix_for_ullman(query_set[i]);
#ifdef SPREFINEMENT
        clear_static_index(query_set[i], 'q');
#endif
    }
    cout << endl;

#ifdef ORIGINAL
    for (int i = 0; i < no_query; i++) {
#ifdef FILTER
        // find one
        if (filter_out.find(i) != filter_out.end()) {
            continue;
        }
#endif
        for (int j = 0; j < no_graph; j++) {
#ifdef FILTER
        // find one
        if (filter_out_g.find(j) != filter_out_g.end()) {
            continue;
        }
#endif

            if (_ullman[i][j] != _en[i][j]) {
                false_positive ++;
            }
        }
    }
#endif

#ifdef FILTER
    no_query -= filter_out.size();
    no_graph -= filter_out_g.size();
#endif

    print_result(out_file, max_cnt_mi, min_cnt_mi, total_cnt_mi, max_cnt_rounding, min_cnt_rounding, total_cnt_rounding, no_query, no_graph, ullman_total_result, en_total_result, false_positive, u_t_time, e_t_time, method2_encrypt_q_time, method2_encrypt_g_time, decryption_time, e_msg_size, _en);

    print_result(cout, max_cnt_mi, min_cnt_mi, total_cnt_mi, max_cnt_rounding, min_cnt_rounding, total_cnt_rounding, no_query, no_graph, ullman_total_result, en_total_result, false_positive, u_t_time, e_t_time, method2_encrypt_q_time,method2_encrypt_g_time,  decryption_time, e_msg_size, _en);

    return 0;
}





