#include "GlobalDataStructures.h"

GlobalVariables CurGlobalVariables;
