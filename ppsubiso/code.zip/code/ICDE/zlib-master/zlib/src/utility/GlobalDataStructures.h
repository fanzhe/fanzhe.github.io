#ifndef GLOBALDATASTRUCTURE_H
#define GLOBALDATASTRUCTURE_H

#include "GlobalDefinition.h"

typedef struct GlobalVariables {
  Algorithm AlgorithmID;
} GlobalVariables;

#endif
